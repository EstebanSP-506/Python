from flask import Flask, render_template, session, redirect, request
import random
app = Flask(__name__)
app.secret_key="ThisIsSecret"

@app.route('/')
def index():
    if 'target' not in session:
        session['target'] = random.randint(0,100)
        session['form_action']="/guess"
        session['button_value']="Guess!"
        session.pop('outcome')
    return render_template('index.html', form_action=session['form_action'], button_value=session['button_value'])

@app.route('/guess', methods=['POST'])
def guess():
    if request.form['number'] == '':
        return redirect('/')
    else: 
        if int(request.form['number']) < session['target']:
            session['outcome'] = "Too Low!"
        elif int(request.form['number']) == session['target']:
            session['outcome'] = str(session['target'])+" was the correct number!!"
            session['form_action']="/reset"
            session['button_value']="Play Again!"
        elif int(request.form['number']) > session['target']:
            session['outcome'] = "Too High!"
        return redirect('/')

@app.route('/reset', methods=['POST'])
def reset():
    session.pop('target')
    return redirect('/')

app.run(debug=True)
 